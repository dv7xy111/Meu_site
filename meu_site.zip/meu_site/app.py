from flask import Flask, render_template, request, redirect, session
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'segredo123'

# Criar banco
if not os.path.exists('users.db'):
    with sqlite3.connect('users.db') as conn:
        conn.execute('CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT)')

# Página pública acessível por qualquer um
@app.route('/contato')
def contato():
    return render_template('contato.html')

@app.route('/')
def home():
    if 'username' in session:
        return redirect('/painel')
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form['username']
        pwd = request.form['password']
        with sqlite3.connect('users.db') as conn:
            cursor = conn.execute('SELECT * FROM users WHERE username=? AND password=?', (user, pwd))
            if cursor.fetchone():
                session['username'] = user
                return redirect('/painel')
            else:
                return 'Login inválido'
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        user = request.form['username']
        pwd = request.form['password']
        try:
            with sqlite3.connect('users.db') as conn:
                conn.execute('INSERT INTO users (username, password) VALUES (?, ?)', (user, pwd))
                return redirect('/login')
        except:
            return 'Usuário já existe'
    return render_template('register.html')

@app.route('/painel')
def painel():
    if 'username' not in session:
        return redirect('/login')
    return render_template('painel.html', username=session['username'])

@app.route('/downloads')
def downloads():
    if 'username' not in session:
        return redirect('/login')
    return render_template('downloads.html')

@app.route('/perfil')
def perfil():
    if 'username' not in session:
        return redirect('/login')
    return render_template('perfil.html', username=session['username'])

@app.route('/editar_senha', methods=['GET', 'POST'])
def editar_senha():
    if 'username' not in session:
        return redirect('/login')
    if request.method == 'POST':
        nova = request.form['nova']
        with sqlite3.connect('users.db') as conn:
            conn.execute('UPDATE users SET password=? WHERE username=?', (nova, session['username']))
        return 'Senha atualizada!'
    return render_template('editar_senha.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/')


